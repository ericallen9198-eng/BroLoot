BroLoot for Windows

1. Extract the entire ZIP into any folder on your PC.
2. Open the extracted BroLoot folder and double-click BroLoot.exe.
3. Use Open profile to load an existing UTL, or edit your targets and choose Export UTL.
4. The Windows Save As dialog lets you choose exactly where to save the profile.

NO LOGIN OR ONLINE GATE
No ChatGPT account, Microsoft account, subscription, license key, or website is required.
The editor runs locally and works offline once its Windows runtime dependencies are present.
Settings stay on the PC. Exports include editor settings so you can reopen them later.

REQUIREMENTS
Windows 10 or 11, 64-bit x64. Requires .NET Framework 4.8 and the Microsoft Edge WebView2 Runtime.
These are present on many current Windows PCs. If WebView2 is missing, BroLoot offers the official free Microsoft installer; no account is needed.
Official WebView2 installer: https://go.microsoft.com/fwlink/p/?LinkId=2124703
.NET Framework 4.8: https://dotnet.microsoft.com/download/dotnet-framework/net48

SHARING
Send this entire ZIP to your allegiance mates. Do not send BroLoot.exe by itself: keep its DLLs and wwwroot folder alongside it.
The downloaded ZIP does not contain anyone's profiles, saved settings, account details, or credentials.

BUILD NOTES
Version 1.1.0. This executable is unsigned and has been cross-compiled, not launched on a Windows machine in this build environment.
The user has confirmed that BroLoot-generated UTL profiles work in-game. That confirmation predates the desktop wrapper.
